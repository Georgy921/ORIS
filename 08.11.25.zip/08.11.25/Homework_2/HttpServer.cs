﻿using System;
using System.Net;
using System.IO;
using System.ComponentModel;
using HTTPServer.shared;

public class HttpServer
{
}